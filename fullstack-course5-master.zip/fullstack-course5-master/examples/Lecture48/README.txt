There is no code to view for this lecture. Instead, feel free to optionally
watch the videos where we visit the client and gather requirements.

It's a fun watch!

However, you're also welcome to skip it if you already watched as part
of the previous course (HTML, CSS, and Javascript for Web Developers) or
if you are simply not interested.
